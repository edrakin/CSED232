async function loadPage(req, res) {
  res.render('pages/login');
}

module.exports = loadPage;
